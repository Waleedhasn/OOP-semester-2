﻿namespace OOP_ProjectDL
{
    public class Class1
    {

    }
}
